package access;

public class Default {

}
