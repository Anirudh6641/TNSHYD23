package project;

public class User {
	public void display() {
		System.out.println("hello");
	}


	}

