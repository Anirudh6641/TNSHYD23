package project;

public class Protected {
	protected void display() {
		System.out.println("hi");
	}

}
