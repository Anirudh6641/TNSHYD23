package project;

public class Default {
	
		void display() {
			System.out.println("hello");
		}

	}
	class default1{
		public static void main(String[] args) {
			Default d=new Default();
			d.display();
		}
	}


