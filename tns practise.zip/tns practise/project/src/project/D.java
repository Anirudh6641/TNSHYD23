package project;

class D {
	private void display()
	{
		System.out.println(" tns program");
	}
	public static void main(String[] args) {
		D d1=new D();
		d1.display();
	}
	
		
	

}

