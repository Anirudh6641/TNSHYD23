package project;

public class User1{
		public void display() {
			System.out.println("welcome");

}
}
