package project;

public class C {
	int a=10;//instance variable
	static int b=20;//static variable
	int display() //instance method
	{
	return 100;
	
	}
	static void display1()//static method
	{
		System.out.println("nani");
	}
}
class E{
	public static void main(String[] args) {
		C d1=new C();
		System.out.println(d1.a);
		System.out.println(C.b);
		d1.display();
		C.display1();
		
		
		
	}
	
	
	
}
