package project;

public class B {
	int a=10;//instance variable
	static int b=20;//static variable
	int display()//instance method 
	{
		return 10;
			}
	static void display1()//static method
	{
		System.out.println("hi");
	}
	public static void main(String[] args)
	{
		B b1=new B();
		System.out.println(b1.a);//accessing instance variable
		System.out.println(B.b);//accessing static variable
		int c=30;
		System.out.println(c);
		b1.display();//accessing instance method
		B.display1();//accessing static method
	}
	

}
