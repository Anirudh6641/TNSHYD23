package project;

public class Public {
	public void display()
	{
		System.out.println("Tns");
	}

}
