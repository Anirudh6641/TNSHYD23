package pack;
import project.*;
import project1.*;

public class User3 {
	public static void main(String[] args) {
		User obj1=new User();
		User1 obj2=new User1();
		User2 obj3=new User2();
		obj1.display();
		obj2.display();
		obj3.display();
		
	}

}
