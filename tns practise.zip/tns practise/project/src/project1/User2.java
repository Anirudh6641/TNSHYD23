package project1;

public class User2 {
	public void display() {
		System.out.println("to tns");
	}

}
