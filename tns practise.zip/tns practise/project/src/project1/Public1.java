package project1;
import project.Public;

public class Public1 {
	public static void main(String[] args) {
		Public obj=new Public();
		obj.display();
	}
}
